from app import db
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import uuid
from flask import url_for

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True)
    password_hash = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), default='manager')  # admin, manager, tenant
    first_name = db.Column(db.String(50))
    last_name = db.Column(db.String(50))
    phone = db.Column(db.String(20))
    is_active = db.Column(db.Boolean, default=True)
    last_login = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Building(db.Model):
    __tablename__ = 'buildings'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = db.Column(db.String(100), nullable=False)
    street = db.Column(db.String(100))
    street_number = db.Column(db.String(10))
    zip_code = db.Column(db.String(10))
    city = db.Column(db.String(50))
    country = db.Column(db.String(50), default='Deutschland')
    year_built = db.Column(db.Integer)
    total_area_sqm = db.Column(db.Float)
    energy_efficiency_class = db.Column(db.String(2))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships - NUR HIER backref definieren
    apartments = db.relationship('Apartment', backref='building', lazy=True, cascade='all, delete-orphan')
    meters = db.relationship('Meter', backref='building', lazy=True, cascade='all, delete-orphan')
    operating_costs = db.relationship('OperatingCost', backref='building', lazy=True, cascade='all, delete-orphan')

class Apartment(db.Model):
    __tablename__ = 'apartments'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    building_id = db.Column(db.String(36), db.ForeignKey('buildings.id'), nullable=False)
    apartment_number = db.Column(db.String(20), nullable=False)
    floor = db.Column(db.String(10))
    area_sqm = db.Column(db.Float)
    room_count = db.Column(db.Integer)
    # ENTFERNEN: building = db.relationship('Building', backref=db.backref('apartments', lazy=True))
    
    # Erweiterte Felder für verschiedene Einheitentypen
    unit_type = db.Column(db.String(20), default='wohnung')  # wohnung, gewerbe, garage, keller, lager, abstellraum
    has_balcony = db.Column(db.Boolean, default=False)
    has_terrace = db.Column(db.Boolean, default=False)
    has_garage = db.Column(db.Boolean, default=False)
    
    # Mietdaten
    rent_net = db.Column(db.Float)
    rent_additional = db.Column(db.Float)
    deposit = db.Column(db.Float)
    rent_start_date = db.Column(db.Date)
    rent_end_date = db.Column(db.Date)
    status = db.Column(db.String(20), default='vacant')  # vacant, occupied, reserved, maintenance
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships - Hier KEINE backref zu Building mehr
    tenants = db.relationship('Tenant', backref='apartment', lazy=True, cascade='all, delete-orphan')
    meters = db.relationship('Meter', backref='apartment', lazy=True, cascade='all, delete-orphan')
    settlements = db.relationship('Settlement', backref='apartment', lazy=True, cascade='all, delete-orphan')
    cost_distributions = db.relationship('CostDistribution', backref='apartment', lazy=True, cascade='all, delete-orphan')
    
    def get_full_identifier(self):
        """Gibt einen vollständigen Identifikator für die Einheit zurück"""
        base = f"{self.building.name} - {self.apartment_number}"
        if self.unit_type != 'wohnung':
            type_names = {
                'wohnung': 'Wohnung',
                'gewerbe': 'Gewerbe',
                'garage': 'Garage',
                'keller': 'Keller',
                'kellerraum': 'Kellerraum',
                'lager': 'Lager',
                'abstellraum': 'Abstellraum',
                'terrasse': 'Terrasse',
                'balkon': 'Balkon',
                'garten': 'Garten',
                'dachboden': 'Dachboden',
                'technikraum': 'Technikraum',
                'waschkueche': 'Waschküche',
                'gemeinschaftsraum': 'Gemeinschaftsraum'
            }
            base = f"{base} ({type_names.get(self.unit_type, self.unit_type)})"
        return base
    
    def get_parent_apartment(self):
        """Findet die übergeordnete Wohnung für Nebeneinheiten"""
        if self.unit_type in ['garage', 'keller', 'kellerraum', 'abstellraum', 'balkon', 'terrasse']:
            # Suche nach einer Wohnung im selben Gebäude mit ähnlicher Nummer
            main_apartment = Apartment.query.filter(
                Apartment.building_id == self.building_id,
                Apartment.unit_type == 'wohnung',
                Apartment.apartment_number == self.apartment_number.split('-')[0]  # Nimmt den Basis-Teil
            ).first()
            return main_apartment
        return None

class Tenant(db.Model):
    __tablename__ = 'tenants'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    apartment_id = db.Column(db.String(36), db.ForeignKey('apartments.id'), nullable=False)
    user_id = db.Column(db.String(36), db.ForeignKey('users.id'))
    
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    date_of_birth = db.Column(db.Date)
    move_in_date = db.Column(db.Date, nullable=False)
    move_out_date = db.Column(db.Date)
    is_primary_tenant = db.Column(db.Boolean, default=True)
    emergency_contact_name = db.Column(db.String(100))
    emergency_contact_phone = db.Column(db.String(20))
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships - KORRIGIERT: Keine direkte Beziehung zu MeterReading mehr
    settlements = db.relationship('Settlement', backref='tenant', lazy=True, cascade='all, delete-orphan')

class MeterType(db.Model):
    __tablename__ = 'meter_types'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = db.Column(db.String(50), nullable=False)
    category = db.Column(db.String(20))  # electricity, water, gas, heating, renewable, special
    unit = db.Column(db.String(10))
    decimal_places = db.Column(db.Integer, default=0)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    meters = db.relationship('Meter', backref='meter_type', lazy=True, cascade='all, delete-orphan')

class Meter(db.Model):
    __tablename__ = 'meters'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    building_id = db.Column(db.String(36), db.ForeignKey('buildings.id'), nullable=False)
    # ENTFERNEN: building = db.relationship('Building', backref=db.backref('meters', lazy=True))
    apartment_id = db.Column(db.String(36), db.ForeignKey('apartments.id'))
    # ENTFERNEN: apartment = db.relationship('Apartment', backref=db.backref('meters', lazy=True))
    parent_meter_id = db.Column(db.String(36), db.ForeignKey('meters.id'))
    meter_type_id = db.Column(db.String(36), db.ForeignKey('meter_types.id'), nullable=False)
    
    meter_number = db.Column(db.String(50), unique=True, nullable=False)
    description = db.Column(db.String(255))
    manufacturer = db.Column(db.String(100))
    model = db.Column(db.String(100))
    installation_date = db.Column(db.Date)
    last_calibration = db.Column(db.Date)
    next_calibration = db.Column(db.Date)
    
    # Zählerkonfiguration
    is_main_meter = db.Column(db.Boolean, default=False)
    is_virtual_meter = db.Column(db.Boolean, default=False)
    multiplier = db.Column(db.Float, default=1.0)
    location_description = db.Column(db.String(255))
    notes = db.Column(db.Text)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships - NUR EINE parent_meter Beziehung
    parent_meter = db.relationship('Meter', remote_side=[id], backref=db.backref('sub_meters', lazy=True))
    readings = db.relationship('MeterReading', backref='meter', lazy=True, cascade='all, delete-orphan')
    operating_costs = db.relationship('OperatingCost', backref='meter', lazy=True, cascade='all, delete-orphan')

class MeterReading(db.Model):
    __tablename__ = 'meter_readings'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    meter_id = db.Column(db.String(36), db.ForeignKey('meters.id'), nullable=False)
    reading_value = db.Column(db.Float, nullable=False)
    reading_date = db.Column(db.Date, nullable=False)
    reading_type = db.Column(db.String(20), default='actual')  # actual, estimated, correction
    photo_path = db.Column(db.String(255))
    notes = db.Column(db.Text)
    created_by = db.Column(db.String(36), db.ForeignKey('users.id'))
    is_manual_entry = db.Column(db.Boolean, default=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref='meter_readings')

class OperatingCost(db.Model):
    __tablename__ = 'operating_costs'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    building_id = db.Column(db.String(36), db.ForeignKey('buildings.id'), nullable=False)
    meter_id = db.Column(db.String(36), db.ForeignKey('meters.id'))
    cost_category_id = db.Column(db.String(36), db.ForeignKey('cost_categories.id'))
    
    description = db.Column(db.String(255))
    amount_net = db.Column(db.Float)
    tax_rate = db.Column(db.Float, default=19.0)
    amount_gross = db.Column(db.Float)
    billing_period_start = db.Column(db.Date)
    billing_period_end = db.Column(db.Date)
    invoice_date = db.Column(db.Date)
    invoice_number = db.Column(db.String(100))
    document_path = db.Column(db.String(255))
    distribution_method = db.Column(db.String(20))  # by_meter, by_area, by_units, by_usage, manual
    is_distributed = db.Column(db.Boolean, default=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    cost_category = db.relationship('CostCategory', backref='operating_costs')
    distributions = db.relationship('CostDistribution', backref='operating_cost', lazy=True, cascade='all, delete-orphan')

class CostCategory(db.Model):
    __tablename__ = 'cost_categories'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(255))
    default_distribution_method = db.Column(db.String(20))  # by_meter, by_area, by_units, by_usage
    is_active = db.Column(db.Boolean, default=True)
    sort_order = db.Column(db.Integer, default=0)

class CostDistribution(db.Model):
    __tablename__ = 'cost_distributions'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    operating_cost_id = db.Column(db.String(36), db.ForeignKey('operating_costs.id'), nullable=False)
    apartment_id = db.Column(db.String(36), db.ForeignKey('apartments.id'), nullable=False)
    meter_id = db.Column(db.String(36), db.ForeignKey('meters.id'))
    
    distributed_amount = db.Column(db.Float)
    distribution_type = db.Column(db.String(50))
    calculation_basis = db.Column(db.Float)
    calculation_note = db.Column(db.String(255))
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Settlement(db.Model):
    __tablename__ = 'settlements'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    apartment_id = db.Column(db.String(36), db.ForeignKey('apartments.id'), nullable=False)
    tenant_id = db.Column(db.String(36), db.ForeignKey('tenants.id'), nullable=False)
    
    settlement_year = db.Column(db.Integer, nullable=False)
    period_start = db.Column(db.Date, nullable=False)
    period_end = db.Column(db.Date, nullable=False)
    total_costs = db.Column(db.Float)
    advance_payments = db.Column(db.Float)
    balance = db.Column(db.Float)
    status = db.Column(db.String(20), default='draft')  # draft, calculated, approved, sent, paid, disputed
    pdf_path = db.Column(db.String(255))
    sent_date = db.Column(db.Date)
    due_date = db.Column(db.Date)
    notes = db.Column(db.Text)
    created_by = db.Column(db.String(36), db.ForeignKey('users.id'))
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref='settlements')

class Document(db.Model):
    __tablename__ = 'documents'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    documentable_type = db.Column(db.String(50))  # building, apartment, tenant, meter, settlement
    documentable_id = db.Column(db.String(36))
    document_type = db.Column(db.String(20))  # contract, meter_reading, invoice, settlement, photo, other
    file_name = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(255), nullable=False)
    file_size = db.Column(db.Integer)
    mime_type = db.Column(db.String(100))
    description = db.Column(db.Text)
    uploaded_by = db.Column(db.String(36), db.ForeignKey('users.id'))
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref='documents')

    def get_download_url(self):
        return url_for('documents.download_document', document_id=self.id)