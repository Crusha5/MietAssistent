from flask import Blueprint, request, jsonify, render_template, redirect, url_for, session
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from app.models import User
from app import db

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    
    user = User.query.filter_by(username=data['username']).first()
    
    if user and user.check_password(data['password']):
        # Identity muss ein String sein
        access_token = create_access_token(identity=str(user.id))
        return jsonify({
            'access_token': access_token,
            'user': {'id': user.id, 'username': user.username}
        })
    
    return jsonify({'error': 'Ungültige Anmeldedaten'}), 401

@auth_bp.route('/web-login', methods=['GET', 'POST'])
def web_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            # Session-basierte Authentifizierung für Web
            session['user_id'] = user.id
            session['username'] = user.username
            return redirect(url_for('main.dashboard'))
        
        return render_template('auth/login.html', error='Ungültige Anmeldedaten')
    
    return render_template('auth/login.html')

@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('main.index'))

@auth_bp.route('/protected')
@jwt_required()
def protected():
    current_user_id = get_jwt_identity()
    user = User.query.get(int(current_user_id))  # Zurück zu Integer konvertieren
    return jsonify({'message': f'Hallo {user.username}'})

@auth_bp.route('/status')
def status():
    return jsonify({'status': 'OK', 'service': 'Rental Management API'})