from flask import Blueprint, request, jsonify, render_template, redirect, url_for, flash
from flask_jwt_extended import jwt_required
from app import db
from app.models import Settlement, Apartment, Tenant, MeterReading
from datetime import datetime
from app.routes.main import login_required

settlements_bp = Blueprint('settlements', __name__)

@settlements_bp.route('/settlements')
@login_required
def settlements_list():
    settlements = Settlement.query.order_by(Settlement.period_end.desc()).all()
    return render_template('settlements/list.html', settlements=settlements)

@settlements_bp.route('/settlements/calculate', methods=['GET', 'POST'])
@login_required
def calculate_settlement():
    apartments = Apartment.query.all()
    
    if request.method == 'POST':
        try:
            apartment_id = int(request.form['apartment_id'])
            period_start = datetime.strptime(request.form['period_start'], '%Y-%m-%d').date()
            period_end = datetime.strptime(request.form['period_end'], '%Y-%m-%d').date()
            
            # Hier würde die eigentliche Abrechnungslogik implementiert werden
            # Dies ist eine vereinfachte Version
            
            apartment = Apartment.query.get(apartment_id)
            tenant = Tenant.query.filter_by(apartment_id=apartment_id, move_out_date=None).first()
            
            if not tenant:
                flash('Kein aktiver Mieter für diese Wohnung gefunden', 'danger')
                return redirect(request.url)
            
            # Beispielberechnung
            total_rent = tenant.rent * 12  # Jahresmiete
            additional_costs = apartment.additional_costs * 12  # Jahresnebenkosten
            
            # Hier würden echte Verbrauchswerte berechnet werden
            heating_costs = 0
            water_costs = 0
            electricity_costs = 0
            
            total_amount = additional_costs + heating_costs + water_costs + electricity_costs
            
            settlement = Settlement(
                period_start=period_start,
                period_end=period_end,
                total_rent=total_rent,
                additional_costs=additional_costs,
                heating_costs=heating_costs,
                water_costs=water_costs,
                electricity_costs=electricity_costs,
                total_amount=total_amount,
                apartment_id=apartment_id,
                tenant_id=tenant.id
            )
            
            db.session.add(settlement)
            db.session.commit()
            
            flash('Abrechnung erfolgreich erstellt!', 'success')
            return redirect(url_for('settlements.settlement_detail', settlement_id=settlement.id))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Fehler beim Erstellen der Abrechnung: {str(e)}', 'danger')
    
    return render_template('settlements/calculate.html', apartments=apartments)

@settlements_bp.route('/settlements/<int:settlement_id>')
@login_required
def settlement_detail(settlement_id):
    settlement = Settlement.query.get_or_404(settlement_id)
    return render_template('settlements/detail.html', settlement=settlement)

@settlements_bp.route('/settlements/<int:settlement_id>/pdf')
@login_required
def download_settlement_pdf(settlement_id):
    settlement = Settlement.query.get_or_404(settlement_id)
    # Hier würde die PDF-Generierung implementiert werden
    flash('PDF-Generierung wird in Kürze verfügbar sein', 'info')
    return redirect(url_for('settlements.settlement_detail', settlement_id=settlement_id))

# API Routes
@settlements_bp.route('/settlements/calculate', methods=['POST'])
@jwt_required()
def calculate_settlement_api():
    data = request.get_json()
    
    # Vereinfachte Berechnung (wie oben)
    apartment = Apartment.query.get(data['apartment_id'])
    tenant = Tenant.query.filter_by(apartment_id=data['apartment_id'], move_out_date=None).first()
    
    if not tenant:
        return jsonify({'error': 'No active tenant found'}), 400
    
    settlement = Settlement(
        period_start=datetime.strptime(data['period_start'], '%Y-%m-%d').date(),
        period_end=datetime.strptime(data['period_end'], '%Y-%m-%d').date(),
        total_rent=tenant.rent * 12,
        additional_costs=apartment.additional_costs * 12,
        total_amount=(tenant.rent + apartment.additional_costs) * 12,
        apartment_id=data['apartment_id'],
        tenant_id=tenant.id
    )
    
    db.session.add(settlement)
    db.session.commit()
    
    return jsonify({
        'message': 'Abrechnung erfolgreich erstellt',
        'id': settlement.id,
        'settlement': settlement.to_dict()
    }), 201

@settlements_bp.route('/settlements/<int:settlement_id>', methods=['GET'])
@jwt_required()
def get_settlement_api(settlement_id):
    settlement = Settlement.query.get_or_404(settlement_id)
    return jsonify(settlement.to_dict())

@settlements_bp.route('/settlements/<int:settlement_id>/pdf', methods=['GET'])
@jwt_required()
def get_settlement_pdf_api(settlement_id):
    settlement = Settlement.query.get_or_404(settlement_id)
    # PDF-Generierung würde hier implementiert werden
    return jsonify({'message': 'PDF generation not yet implemented'})