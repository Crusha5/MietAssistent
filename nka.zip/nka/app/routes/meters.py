from flask import Blueprint, request, jsonify, render_template, redirect, url_for, flash
from flask_jwt_extended import jwt_required
from app.models import Meter, MeterType, Building, Apartment, MeterReading, User
from app.routes.main import login_required
from datetime import datetime
import uuid

# Database import from Flask current_app context
from flask import current_app
from app import db

meters_bp = Blueprint('meters', __name__)

@meters_bp.route('/meters')
@login_required
def meters_list():
    meters = Meter.query.all()
    buildings = Building.query.all()
    meter_types = MeterType.query.all()
    return render_template('meters/list.html', 
                         meters=meters, 
                         buildings=buildings,
                         meter_types=meter_types)

@meters_bp.route('/create', methods=['GET', 'POST'])
@meters_bp.route('/meters/create', methods=['GET', 'POST'])
@login_required
def create_meter():
    # Gebäudedaten mitladen für die Anzeige
    buildings = Building.query.all()
    apartments = Apartment.query.options(db.joinedload(Apartment.building)).all()
    
    # ✅ KORREKTUR: Nur aktive Zählertypen anzeigen
    meter_types = MeterType.query.filter_by(is_active=True).order_by(MeterType.name).all()
    
    parent_meters = Meter.query.filter_by(is_main_meter=True).all()
    
    if request.method == 'POST':
        try:
            parent_meter_id = request.form.get('parent_meter_id') or None
            
            # ✅ KORREKTUR: Automatisch is_main_meter setzen
            is_main_meter = parent_meter_id is None

            meter = Meter(
                id=str(uuid.uuid4()),
                meter_number=request.form['meter_number'],
                description=request.form.get('description', ''),
                building_id=request.form['building_id'],
                apartment_id=request.form.get('apartment_id') or None,
                parent_meter_id=parent_meter_id,
                meter_type_id=request.form['meter_type_id'],
                manufacturer=request.form.get('manufacturer', ''),
                model=request.form.get('model', ''),
                installation_date=datetime.strptime(request.form['installation_date'], '%Y-%m-%d').date() if request.form.get('installation_date') else None,
                is_main_meter=is_main_meter,  # ✅ Automatisch gesetzt
                is_virtual_meter=bool(request.form.get('is_virtual_meter')),
                multiplier=float(request.form.get('multiplier', 1.0)),
                location_description=request.form.get('location_description', ''),
                notes=request.form.get('notes', '')
            )
            
            db.session.add(meter)
            db.session.commit()
            flash('Zähler erfolgreich angelegt!', 'success')
            return redirect(url_for('meters.meters_list'))
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Fehler beim Anlegen des Zählers: {str(e)}", exc_info=True)
            flash(f'Fehler beim Anlegen des Zählers: {str(e)}', 'danger')
    
    return render_template('meters/create.html', 
                         buildings=buildings,
                         apartments=apartments, 
                         meter_types=meter_types,
                         parent_meters=parent_meters)

@meters_bp.route('/meters/<meter_id>')
@login_required
def meter_detail(meter_id):
    meter = Meter.query.get_or_404(meter_id)
    readings = MeterReading.query.filter_by(meter_id=meter_id).order_by(MeterReading.reading_date.desc()).all()
    sub_meters = Meter.query.filter_by(parent_meter_id=meter_id).all()
    return render_template('meters/detail.html', 
                         meter=meter, 
                         readings=readings,
                         sub_meters=sub_meters)

@meters_bp.route('/meters/<meter_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_meter(meter_id):
    meter = Meter.query.get_or_404(meter_id)
    buildings = Building.query.all()
    apartments = Apartment.query.all()
    
    # ✅ KORREKT: Nur aktive Zählertypen anzeigen
    meter_types = MeterType.query.filter_by(is_active=True).order_by(MeterType.name).all()
    
    parent_meters = Meter.query.filter(Meter.id != meter_id).filter_by(is_main_meter=True).all()
    
    if request.method == 'POST':
        try:
            parent_meter_id = request.form.get('parent_meter_id') or None
            
            # ✅ KORREKT: Automatisch is_main_meter setzen
            is_main_meter = parent_meter_id is None

            meter.meter_number = request.form['meter_number']
            meter.description = request.form.get('description', '')
            meter.building_id = request.form['building_id']
            meter.apartment_id = request.form.get('apartment_id') or None
            meter.parent_meter_id = parent_meter_id
            meter.meter_type_id = request.form['meter_type_id']
            meter.manufacturer = request.form.get('manufacturer', '')
            meter.model = request.form.get('model', '')
            meter.installation_date = datetime.strptime(request.form['installation_date'], '%Y-%m-%d').date() if request.form.get('installation_date') else None
            meter.is_main_meter = is_main_meter  # ✅ Automatisch gesetzt
            meter.is_virtual_meter = bool(request.form.get('is_virtual_meter'))
            meter.multiplier = float(request.form.get('multiplier', 1.0))
            meter.location_description = request.form.get('location_description', '')
            meter.notes = request.form.get('notes', '')
            
            db.session.commit()
            flash('Zähler erfolgreich aktualisiert!', 'success')
            return redirect(url_for('meters.meter_detail', meter_id=meter.id))
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Fehler beim Aktualisieren des Zählers: {str(e)}", exc_info=True)
            flash(f'Fehler beim Aktualisieren des Zählers: {str(e)}', 'danger')
    
    return render_template('meters/edit.html', 
                         meter=meter,
                         buildings=buildings,
                         apartments=apartments, 
                         meter_types=meter_types,
                         parent_meters=parent_meters)

@meters_bp.route('/meters/<meter_id>/delete', methods=['POST'])
@login_required
def delete_meter(meter_id):
    meter = Meter.query.get_or_404(meter_id)
    
    try:
        # Prüfen ob Unterzähler existieren
        sub_meters = Meter.query.filter_by(parent_meter_id=meter_id).count()
        if sub_meters > 0:
            flash('Kann Zähler nicht löschen: Es existieren noch Unterzähler!', 'danger')
            return redirect(url_for('meters.meter_detail', meter_id=meter_id))
        
        # Prüfen ob Zählerstände existieren
        readings_count = MeterReading.query.filter_by(meter_id=meter_id).count()
        if readings_count > 0:
            flash('Kann Zähler nicht löschen: Es existieren noch Zählerstände!', 'danger')
            return redirect(url_for('meters.meter_detail', meter_id=meter_id))
        
        db.session.delete(meter)
        db.session.commit()
        flash('Zähler erfolgreich gelöscht!', 'success')
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Fehler beim Löschen des Zählers: {str(e)}", exc_info=True)
        flash(f'Fehler beim Löschen des Zählers: {str(e)}', 'danger')
    
    return redirect(url_for('meters.meters_list'))

@meters_bp.route('/meters/<meter_id>/hierarchy')
@login_required
def meter_hierarchy(meter_id):
    meter = Meter.query.get_or_404(meter_id)
    
    # Hierarchie aufbauen
    def build_hierarchy(current_meter):
        hierarchy = {
            'meter': current_meter,
            'sub_meters': []
        }
        
        sub_meters = Meter.query.filter_by(parent_meter_id=current_meter.id).all()
        for sub_meter in sub_meters:
            hierarchy['sub_meters'].append(build_hierarchy(sub_meter))
            
        return hierarchy
    
    hierarchy = build_hierarchy(meter)
    return render_template('meters/hierarchy.html', hierarchy=hierarchy)

@meters_bp.route('/meters/<meter_id>/add-submeter', methods=['GET', 'POST'])
@login_required
def add_submeter(meter_id):
    parent_meter = Meter.query.get_or_404(meter_id)
    buildings = Building.query.all()
    apartments = Apartment.query.all()
    
    # ✅ KORREKT: Nur aktive Zählertypen anzeigen
    meter_types = MeterType.query.filter_by(is_active=True).order_by(MeterType.name).all()
    
    if request.method == 'POST':
        try:
            submeter = Meter(
                id=str(uuid.uuid4()),
                meter_number=request.form['meter_number'],
                description=request.form.get('description', ''),
                building_id=parent_meter.building_id,  # Unterzähler gehört zum selben Gebäude
                apartment_id=request.form.get('apartment_id') or None,
                parent_meter_id=parent_meter.id,
                meter_type_id=request.form['meter_type_id'],
                manufacturer=request.form.get('manufacturer', ''),
                model=request.form.get('model', ''),
                installation_date=datetime.strptime(request.form['installation_date'], '%Y-%m-%d').date() if request.form.get('installation_date') else None,
                is_main_meter=False,  # Unterzähler sind nie Hauptzähler
                is_virtual_meter=bool(request.form.get('is_virtual_meter')),
                multiplier=float(request.form.get('multiplier', 1.0)),
                location_description=request.form.get('location_description', ''),
                notes=request.form.get('notes', '')
            )
            
            db.session.add(submeter)
            db.session.commit()
            flash('Unterzähler erfolgreich angelegt!', 'success')
            return redirect(url_for('meters.meter_hierarchy', meter_id=parent_meter.id))
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Fehler beim Anlegen des Unterzählers: {str(e)}", exc_info=True)
            flash(f'Fehler beim Anlegen des Unterzählers: {str(e)}', 'danger')
    
    return render_template('meters/add_submeter.html', 
                         parent_meter=parent_meter,
                         buildings=buildings,
                         apartments=apartments, 
                         meter_types=meter_types)

# API Routes für Gebäude-Wohnungen
@meters_bp.route('/api/buildings/<building_id>/apartments', methods=['GET'])
def web_api_building_apartments(building_id):
    try:
        apartments = Apartment.query.filter_by(building_id=building_id).all()
        
        return jsonify([{
            'id': apartment.id,
            'apartment_number': apartment.apartment_number,
            'building_name': apartment.building.name if apartment.building else None
        } for apartment in apartments])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@meters_bp.route('/api/buildings/<building_id>/meters', methods=['GET'])
def web_api_building_meters(building_id):
    try:
        # NUR Hauptzähler anzeigen (ohne übergeordneten Zähler)
        meters = Meter.query.filter_by(
            building_id=building_id, 
            is_main_meter=True
        ).all()
        
        return jsonify([{
            'id': meter.id,
            'meter_number': meter.meter_number,
            'description': meter.description,
            'apartment_id': meter.apartment_id,
            'apartment_number': meter.apartment.apartment_number if meter.apartment else None,
            'meter_type': meter.meter_type.name,
            'meter_type_category': meter.meter_type.category,
            'is_main_meter': meter.is_main_meter,
            'is_virtual_meter': meter.is_virtual_meter
        } for meter in meters])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# API Routes
@meters_bp.route('/api/meters', methods=['GET'])
@jwt_required()
def get_meters_api():
    meters = Meter.query.all()
    return jsonify([{
        'id': meter.id,
        'meter_number': meter.meter_number,
        'description': meter.description,
        'building_id': meter.building_id,
        'building_name': meter.building.name if meter.building else None,
        'apartment_id': meter.apartment_id,
        'apartment_number': meter.apartment.apartment_number if meter.apartment else None,
        'parent_meter_id': meter.parent_meter_id,
        'meter_type': meter.meter_type.name,
        'meter_type_category': meter.meter_type.category,
        'unit': meter.meter_type.unit,
        'is_main_meter': meter.is_main_meter,
        'is_virtual_meter': meter.is_virtual_meter,
        'multiplier': float(meter.multiplier) if meter.multiplier else 1.0,
        'installation_date': meter.installation_date.isoformat() if meter.installation_date else None,
        'location_description': meter.location_description
    } for meter in meters])

@meters_bp.route('/api/meters', methods=['POST'])
@jwt_required()
def create_meter_api():
    data = request.get_json()
    
    try:
        parent_meter_id = data.get('parent_meter_id')
        is_main_meter = parent_meter_id is None

        meter = Meter(
            id=str(uuid.uuid4()),
            meter_number=data['meter_number'],
            description=data.get('description', ''),
            building_id=data['building_id'],
            apartment_id=data.get('apartment_id'),
            parent_meter_id=parent_meter_id,
            meter_type_id=data['meter_type_id'],
            manufacturer=data.get('manufacturer', ''),
            model=data.get('model', ''),
            installation_date=datetime.fromisoformat(data['installation_date']).date() if data.get('installation_date') else None,
            is_main_meter=is_main_meter,  # ✅ Automatisch gesetzt
            is_virtual_meter=data.get('is_virtual_meter', False),
            multiplier=data.get('multiplier', 1.0),
            location_description=data.get('location_description', ''),
            notes=data.get('notes', '')
        )
        
        db.session.add(meter)
        db.session.commit()
        
        return jsonify({
            'message': 'Zähler erfolgreich angelegt',
            'id': meter.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Fehler beim Anlegen des Zählers (API): {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 400

@meters_bp.route('/api/meters/<meter_id>', methods=['GET'])
@jwt_required()
def get_meter_api(meter_id):
    meter = Meter.query.get_or_404(meter_id)
    
    return jsonify({
        'id': meter.id,
        'meter_number': meter.meter_number,
        'description': meter.description,
        'building_id': meter.building_id,
        'apartment_id': meter.apartment_id,
        'parent_meter_id': meter.parent_meter_id,
        'meter_type_id': meter.meter_type_id,
        'manufacturer': meter.manufacturer,
        'model': meter.model,
        'installation_date': meter.installation_date.isoformat() if meter.installation_date else None,
        'last_calibration': meter.last_calibration.isoformat() if meter.last_calibration else None,
        'next_calibration': meter.next_calibration.isoformat() if meter.next_calibration else None,
        'is_main_meter': meter.is_main_meter,
        'is_virtual_meter': meter.is_virtual_meter,
        'multiplier': float(meter.multiplier) if meter.multiplier else 1.0,
        'location_description': meter.location_description,
        'notes': meter.notes,
        'created_at': meter.created_at.isoformat(),
        'updated_at': meter.updated_at.isoformat()
    })

@meters_bp.route('/api/meters/<meter_id>/readings', methods=['GET'])
@jwt_required()
def get_meter_readings_api(meter_id):
    readings = MeterReading.query.filter_by(meter_id=meter_id).order_by(MeterReading.reading_date.desc()).all()
    
    return jsonify([{
        'id': reading.id,
        'reading_value': float(reading.reading_value),
        'reading_date': reading.reading_date.isoformat(),
        'reading_type': reading.reading_type,
        'photo_path': reading.photo_path,
        'notes': reading.notes,
        'created_at': reading.created_at.isoformat()
    } for reading in readings])

@meters_bp.route('/api/meters/types', methods=['GET'])
@jwt_required()
def get_meter_types_api():
    meter_types = MeterType.query.filter_by(is_active=True).all()
    
    return jsonify([{
        'id': mt.id,
        'name': mt.name,
        'category': mt.category,
        'unit': mt.unit,
        'decimal_places': mt.decimal_places
    } for mt in meter_types])