from flask import Blueprint, request, jsonify, render_template, redirect, url_for, flash, session
from flask_jwt_extended import jwt_required
from app import db
from app.models import MeterReading, Meter, MeterType, Apartment, Tenant, User
from datetime import datetime
from app.routes.main import login_required
import os
from werkzeug.utils import secure_filename
import uuid

meter_bp = Blueprint('meter_readings', __name__)

# Konfiguration für Datei-Uploads
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'heic'}
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@meter_bp.route('/meter-readings')
@login_required
def meter_readings_list():
    readings = MeterReading.query.order_by(MeterReading.reading_date.desc()).all()
    return render_template('meter_readings/list.html', readings=readings)

@meter_bp.route('/create', methods=['GET', 'POST'])
@meter_bp.route('/meter-readings/create', methods=['GET', 'POST'])
@login_required
def create_meter_reading():
    meter_id = request.args.get('meter_id')
    selected_meter = None
    
    if meter_id:
        selected_meter = Meter.query.get(meter_id)
    
    meters = Meter.query.all()
    
    if request.method == 'POST':
        try:
            # Debug: Formulardaten ausgeben
            print("Form data:", dict(request.form))
            
            # Erstelle Zählerstand mit allen erforderlichen Feldern
            reading = MeterReading(
                id=str(uuid.uuid4()),
                meter_id=request.form['meter_id'],
                reading_value=float(request.form['reading_value']),
                reading_date=datetime.strptime(request.form['reading_date'], '%Y-%m-%d').date(),
                reading_type=request.form.get('reading_type', 'actual'),
                notes=request.form.get('notes', ''),
                is_manual_entry=True,
                created_by=session.get('user_id')  # Verwende Session User ID
            )
            
            # Foto-Upload verarbeiten
            if 'photo' in request.files:
                file = request.files['photo']
                if file and file.filename and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    unique_filename = f"{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{filename}"
                    upload_dir = os.path.join(current_app.config['UPLOAD_FOLDER'], 'meter_photos')
                    os.makedirs(upload_dir, exist_ok=True)
                    file_path = os.path.join(upload_dir, unique_filename)
                    file.save(file_path)
                    reading.photo_path = unique_filename
            
            db.session.add(reading)
            db.session.commit()
            flash('Zählerstand erfolgreich erfasst!', 'success')
            return redirect(url_for('meter_readings.meter_readings_list'))
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Fehler beim Erfassen des Zählerstands: {str(e)}", exc_info=True)
            flash(f'Fehler beim Erfassen des Zählerstands: {str(e)}', 'danger')
    
    return render_template('meter_readings/create.html', 
                         meters=meters,
                         selected_meter=selected_meter)

@meter_bp.route('/<reading_id>')
@meter_bp.route('/meter-readings/<reading_id>')
@login_required
def reading_detail(reading_id):
    reading = MeterReading.query.get_or_404(reading_id)
    return render_template('meter_readings/detail.html', reading=reading)

# API Routes
@meter_bp.route('/api/meter-readings', methods=['GET'])
@jwt_required()
def get_meter_readings_api():
    readings = MeterReading.query.all()
    return jsonify([{
        'id': reading.id,
        'meter_id': reading.meter_id,
        'reading_value': float(reading.reading_value),
        'reading_date': reading.reading_date.isoformat(),
        'reading_type': reading.reading_type,
        'notes': reading.notes,
        'created_at': reading.created_at.isoformat()
    } for reading in readings])

@meter_bp.route('/api/meter-readings', methods=['POST'])
@jwt_required()
def create_meter_reading_api():
    data = request.get_json()
    
    try:
        reading = MeterReading(
            id=str(uuid.uuid4()),
            meter_id=data['meter_id'],
            reading_value=float(data['reading_value']),
            reading_date=datetime.fromisoformat(data['reading_date']).date(),
            reading_type=data.get('reading_type', 'actual'),
            notes=data.get('notes', ''),
            is_manual_entry=True
        )
        
        db.session.add(reading)
        db.session.commit()
        
        return jsonify({
            'message': 'Zählerstand erfolgreich erfasst',
            'id': reading.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

@meter_bp.route('/api/meters/<meter_id>/readings', methods=['GET'])
@jwt_required()
def get_meter_readings_by_meter(meter_id):
    readings = MeterReading.query.filter_by(meter_id=meter_id).order_by(MeterReading.reading_date.desc()).all()
    return jsonify([{
        'id': reading.id,
        'reading_value': float(reading.reading_value),
        'reading_date': reading.reading_date.isoformat(),
        'reading_type': reading.reading_type,
        'notes': reading.notes,
        'created_at': reading.created_at.isoformat()
    } for reading in readings])