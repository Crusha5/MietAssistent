from flask import Blueprint, request, jsonify, render_template, redirect, url_for, flash, send_file
from flask_jwt_extended import jwt_required
from app import db
from app.models import Document, Apartment, Tenant
from datetime import datetime
from app.routes.main import login_required
import os
from werkzeug.utils import secure_filename

documents_bp = Blueprint('documents', __name__)

# Konfiguration für Datei-Uploads
ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png', 'txt'}
MAX_FILE_SIZE = 16 * 1024 * 1024  # 16MB

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@documents_bp.route('/documents')
@login_required
def documents_list():
    documents = Document.query.order_by(Document.created_at.desc()).all()
    return render_template('documents/list.html', documents=documents)

@documents_bp.route('/documents/upload', methods=['GET', 'POST'])
@login_required
def upload_document():
    apartments = Apartment.query.all()
    tenants = Tenant.query.all()
    
    if request.method == 'POST':
        try:
            if 'file' not in request.files:
                flash('Keine Datei ausgewählt', 'danger')
                return redirect(request.url)
            
            file = request.files['file']
            if file.filename == '':
                flash('Keine Datei ausgewählt', 'danger')
                return redirect(request.url)
            
            if file and allowed_file(file.filename):
                # Dateigröße prüfen
                file.seek(0, 2)  # Zum Ende der Datei springen
                file_size = file.tell()
                file.seek(0)  # Zurück zum Anfang
                
                if file_size > MAX_FILE_SIZE:
                    flash('Datei ist zu groß (max. 16MB)', 'danger')
                    return redirect(request.url)
                
                # Datei speichern
                filename = secure_filename(file.filename)
                unique_filename = f"{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{filename}"
                file_path = os.path.join('uploads', 'documents', unique_filename)
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
                file.save(file_path)
                
                # Dokument in Datenbank speichern
                document = Document(
                    filename=unique_filename,
                    original_filename=filename,
                    file_type=file.content_type,
                    file_size=file_size,
                    category=request.form['category'],
                    description=request.form.get('description'),
                    apartment_id=request.form.get('apartment_id') or None,
                    tenant_id=request.form.get('tenant_id') or None
                )
                
                db.session.add(document)
                db.session.commit()
                flash('Dokument erfolgreich hochgeladen!', 'success')
                return redirect(url_for('documents.documents_list'))
            else:
                flash('Ungültiger Dateityp', 'danger')
                
        except Exception as e:
            db.session.rollback()
            flash(f'Fehler beim Hochladen: {str(e)}', 'danger')
    
    return render_template('documents/upload.html', 
                         apartments=apartments, 
                         tenants=tenants)

@documents_bp.route('/documents/<int:document_id>/download')
@login_required
def download_document(document_id):
    document = Document.query.get_or_404(document_id)
    file_path = os.path.join('uploads', 'documents', document.filename)
    
    if not os.path.exists(file_path):
        flash('Datei nicht gefunden', 'danger')
        return redirect(url_for('documents.documents_list'))
    
    return send_file(file_path, 
                    as_attachment=True, 
                    download_name=document.original_filename)

@documents_bp.route('/documents/<int:document_id>/delete', methods=['POST'])
@login_required
def delete_document(document_id):
    document = Document.query.get_or_404(document_id)
    
    try:
        # Datei löschen
        file_path = os.path.join('uploads', 'documents', document.filename)
        if os.path.exists(file_path):
            os.remove(file_path)
        
        # Datenbank-Eintrag löschen
        db.session.delete(document)
        db.session.commit()
        flash('Dokument erfolgreich gelöscht!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Fehler beim Löschen: {str(e)}', 'danger')
    
    return redirect(url_for('documents.documents_list'))

# API Routes
@documents_bp.route('/documents', methods=['GET'])
@jwt_required()
def get_documents_api():
    documents = Document.query.all()
    return jsonify([{
        'id': doc.id,
        'original_filename': doc.original_filename,
        'file_type': doc.file_type,
        'file_size': doc.file_size,
        'category': doc.category,
        'description': doc.description,
        'created_at': doc.created_at.isoformat(),
        'apartment_number': doc.apartment.number if doc.apartment else None,
        'tenant_name': f"{doc.tenant.first_name} {doc.tenant.last_name}" if doc.tenant else None
    } for doc in documents])

@documents_bp.route('/documents/upload', methods=['POST'])
@jwt_required()
def upload_document_api():
    # API Upload ähnlich wie Web-Upload, aber mit JSON Response
    pass

@documents_bp.route('/documents/<int:document_id>', methods=['GET'])
@jwt_required()
def download_document_api(document_id):
    document = Document.query.get_or_404(document_id)
    file_path = os.path.join('uploads', 'documents', document.filename)
    
    if not os.path.exists(file_path):
        return jsonify({'error': 'File not found'}), 404
    
    return send_file(file_path, 
                    as_attachment=True, 
                    download_name=document.original_filename)