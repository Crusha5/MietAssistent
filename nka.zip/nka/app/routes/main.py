from flask import Blueprint, render_template, redirect, url_for, session, request, flash
from app.models import User, Apartment, Tenant, Building, Meter, MeterType, MeterReading, Document, Settlement
from datetime import datetime
import uuid
from app import db

main_bp = Blueprint('main', __name__)

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.web_login'))
        return f(*args, **kwargs)
    return decorated_function

@main_bp.route('/')
def index():
    # Wenn kein Benutzer in der Datenbank existiert, zum Setup weiterleiten
    if not User.query.first():
        return redirect('/setup')
    
    # Wenn der Benutzer nicht in der Session ist, zum Login weiterleiten
    if 'user_id' not in session:
        return redirect('/login')
    
    # Ansonsten Dashboard anzeigen
    apartments = Apartment.query.all()
    tenants = Tenant.query.all()
    buildings = Building.query.all()
    
    # Statistiken berechnen
    stats = {
        'apartment_count': len(apartments),
        'tenant_count': len(tenants),
        'building_count': len(buildings),
        'occupied_count': len([apt for apt in apartments if apt.status == 'occupied']),
        'vacant_count': len([apt for apt in apartments if apt.status == 'vacant'])
    }
    
    return render_template('main/dashboard.html', 
                         stats=stats, 
                         apartments=apartments,
                         now=datetime.now())

@main_bp.route('/dashboard')
@login_required
def dashboard():
    user_id = session.get('user_id')
    user = User.query.get(user_id)
    
    # Statistiken berechnen
    apartments = Apartment.query.all()
    tenants = Tenant.query.all()
    buildings = Building.query.all()
    meters = Meter.query.all()
    
    stats = {
        'apartment_count': len(apartments),
        'tenant_count': len(tenants),
        'building_count': len(buildings),
        'occupied_count': len([apt for apt in apartments if apt.status == 'occupied']),
        'vacant_count': len([apt for apt in apartments if apt.status == 'vacant'])
    }
    
    # Echte Aktivitäten sammeln
    activities = []
    
    # Neueste Wohnungen
    recent_apartments = Apartment.query.order_by(Apartment.created_at.desc()).limit(3).all()
    for apt in recent_apartments:
        activities.append({
            'type': 'apartment_created',
            'message': f'Wohnung {apt.apartment_number} angelegt',
            'timestamp': apt.created_at,
            'icon': 'bi-building',
            'color': 'primary'
        })
    
    # Neueste Mieter
    recent_tenants = Tenant.query.order_by(Tenant.created_at.desc()).limit(3).all()
    for tenant in recent_tenants:
        activities.append({
            'type': 'tenant_created', 
            'message': f'Mieter {tenant.first_name} {tenant.last_name} angelegt',
            'timestamp': tenant.created_at,
            'icon': 'bi-person',
            'color': 'success'
        })
    
    # Neueste Zählerstände
    recent_readings = MeterReading.query.order_by(MeterReading.created_at.desc()).limit(3).all()
    for reading in recent_readings:
        activities.append({
            'type': 'meter_reading',
            'message': f'Zählerstand für {reading.meter.meter_number} erfasst',
            'timestamp': reading.created_at,
            'icon': 'bi-speedometer2',
            'color': 'info'
        })
    
    # Nach Zeitstempel sortieren (neueste zuerst)
    activities.sort(key=lambda x: x['timestamp'], reverse=True)
    # Nur die 5 neuesten Aktivitäten anzeigen
    activities = activities[:5]
    
    return render_template('main/dashboard.html', 
                         user=user,
                         stats=stats,
                         apartments=apartments,
                         activities=activities,
                         now=datetime.now())

@main_bp.route('/login')
def login_page():
    return redirect(url_for('auth.web_login'))

# Apartments Routes
# ENTFERNT: Diese Routes werden jetzt von den Blueprints gehandelt
# @main_bp.route('/apartments')
# @main_bp.route('/apartments/create')

# Tenants Routes
# @main_bp.route('/tenants')
@login_required
def tenants_page():
    tenants = Tenant.query.all()
    return render_template('tenants/list.html', tenants=tenants)

# @main_bp.route('/tenants/create', methods=['GET', 'POST'])
@login_required
def create_tenant_page():
    if request.method == 'POST':
        try:
            tenant = Tenant(
                id=str(uuid.uuid4()),
                first_name=request.form['first_name'],
                last_name=request.form['last_name'],
                email=request.form.get('email'),
                phone=request.form.get('phone'),
                move_in_date=datetime.strptime(request.form['move_in_date'], '%Y-%m-%d').date(),
                apartment_id=request.form['apartment_id'],
                is_primary_tenant=True
            )
            
            db.session.add(tenant)
            db.session.commit()
            flash('Mieter erfolgreich angelegt!', 'success')
            return redirect(url_for('main.tenants_page'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Fehler beim Anlegen des Mieters: {str(e)}', 'danger')
    
    apartments = Apartment.query.options(db.joinedload(Apartment.building)).all()
    return render_template('tenants/create.html', apartments=apartments)

# @main_bp.route('/tenants/<tenant_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_tenant_page(tenant_id):
    tenant = Tenant.query.get_or_404(tenant_id)
    
    if request.method == 'POST':
        try:
            tenant.first_name = request.form['first_name']
            tenant.last_name = request.form['last_name']
            tenant.email = request.form.get('email')
            tenant.phone = request.form.get('phone')
            tenant.move_in_date = datetime.strptime(request.form['move_in_date'], '%Y-%m-%d').date()
            
            if request.form.get('move_out_date'):
                tenant.move_out_date = datetime.strptime(request.form['move_out_date'], '%Y-%m-%d').date()
            else:
                tenant.move_out_date = None
                
            tenant.rent = float(request.form['rent'])
            tenant.person_count = float(request.form['person_count'])
            tenant.apartment_id = request.form['apartment_id']  # UUID, nicht Integer
            
            db.session.commit()
            flash('Mieter erfolgreich aktualisiert!', 'success')
            return redirect(url_for('main.tenants_page'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Fehler beim Aktualisieren des Mieters: {str(e)}', 'danger')
    
    apartments = Apartment.query.all()
    return render_template('tenants/edit.html', tenant=tenant, apartments=apartments)

# Meters Routes
@main_bp.route('/meters')
@login_required
def meters_page():
    meters = Meter.query.all()
    return render_template('meters/list.html', meters=meters)

@main_bp.route('/meters/create', methods=['GET', 'POST'])
@login_required
def create_meter_page():
    if request.method == 'POST':
        try:
            meter = Meter(
                meter_number=request.form['meter_number'],
                description=request.form.get('description'),
                initial_reading=float(request.form.get('initial_reading', 0)),
                apartment_id=request.form.get('apartment_id'),  # UUID, kann None sein
                meter_type_id=request.form['meter_type_id']
            )
            
            db.session.add(meter)
            db.session.commit()
            flash('Zähler erfolgreich angelegt!', 'success')
            return redirect(url_for('main.meters_page'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Fehler beim Anlegen des Zählers: {str(e)}', 'danger')
    
    apartments = Apartment.query.all()
    meter_types = MeterType.query.all()
    return render_template('meters/create.html', apartments=apartments, meter_types=meter_types)

# Meter Readings Routes
@main_bp.route('/meter-readings')
@login_required
def meter_readings_page():
    readings = MeterReading.query.order_by(MeterReading.reading_date.desc()).all()
    return render_template('meter_readings/list.html', readings=readings)

@main_bp.route('/meter-readings/create', methods=['GET', 'POST'])
@login_required
def create_meter_reading_page():
    if request.method == 'POST':
        try:
            reading = MeterReading(
                reading_value=float(request.form['value']),
                reading_date=datetime.strptime(request.form['reading_date'], '%Y-%m-%d').date(),
                notes=request.form.get('notes'),
                meter_id=request.form['meter_id']
            )
            
            db.session.add(reading)
            db.session.commit()
            flash('Zählerstand erfolgreich erfasst!', 'success')
            return redirect(url_for('main.meter_readings_page'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Fehler beim Erfassen des Zählerstands: {str(e)}', 'danger')
    
    apartments = Apartment.query.all()
    meters = Meter.query.all()
    return render_template('meter_readings/create.html', apartments=apartments, meters=meters)

# Documents Routes
@main_bp.route('/documents')
@login_required
def documents_page():
    documents = Document.query.order_by(Document.created_at.desc()).all()
    return render_template('documents/list.html', documents=documents)

@main_bp.route('/documents/upload', methods=['GET', 'POST'])
@login_required
def upload_document_page():
    if request.method == 'POST':
        try:
            if 'file' not in request.files:
                flash('Keine Datei ausgewählt', 'danger')
                return redirect(request.url)
            
            file = request.files['file']
            if file.filename == '':
                flash('Keine Datei ausgewählt', 'danger')
                return redirect(request.url)
            
            # Vereinfachte Datei-Prüfung
            if file and '.' in file.filename:
                # Datei speichern
                import os
                from werkzeug.utils import secure_filename
                
                filename = secure_filename(file.filename)
                unique_filename = f"{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{filename}"
                file_path = os.path.join('uploads', 'documents', unique_filename)
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
                file.save(file_path)
                
                # Dokument in Datenbank speichern
                document = Document(
                    filename=unique_filename,
                    original_filename=filename,
                    file_type=file.content_type or 'application/octet-stream',
                    file_size=os.path.getsize(file_path),
                    category=request.form['category'],
                    description=request.form.get('description'),
                    apartment_id=request.form.get('apartment_id') or None,
                    tenant_id=request.form.get('tenant_id') or None
                )
                
                db.session.add(document)
                db.session.commit()
                flash('Dokument erfolgreich hochgeladen!', 'success')
                return redirect(url_for('main.documents_page'))
            else:
                flash('Ungültige Datei', 'danger')
                
        except Exception as e:
            db.session.rollback()
            flash(f'Fehler beim Hochladen: {str(e)}', 'danger')
    
    apartments = Apartment.query.all()
    tenants = Tenant.query.all()
    return render_template('documents/upload.html', apartments=apartments, tenants=tenants)

@main_bp.route('/documents/<document_id>/download')
@login_required
def download_document_page(document_id):
    from flask import send_file
    import os
    
    document = Document.query.get_or_404(document_id)
    file_path = os.path.join('uploads', 'documents', document.filename)
    
    if not os.path.exists(file_path):
        flash('Datei nicht gefunden', 'danger')
        return redirect(url_for('main.documents_page'))
    
    return send_file(file_path, as_attachment=True, download_name=document.original_filename)

@main_bp.route('/documents/<document_id>/delete', methods=['POST'])
@login_required
def delete_document_page(document_id):
    import os
    
    document = Document.query.get_or_404(document_id)
    
    try:
        # Datei löschen
        file_path = os.path.join('uploads', 'documents', document.filename)
        if os.path.exists(file_path):
            os.remove(file_path)
        
        # Datenbank-Eintrag löschen
        db.session.delete(document)
        db.session.commit()
        flash('Dokument erfolgreich gelöscht!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Fehler beim Löschen: {str(e)}', 'danger')
    
    return redirect(url_for('main.documents_page'))

# Settlements Routes
@main_bp.route('/settlements')
@login_required
def settlements_page():
    settlements = Settlement.query.order_by(Settlement.period_end.desc()).all()
    return render_template('settlements/list.html', settlements=settlements)

@main_bp.route('/settlements/calculate', methods=['GET', 'POST'])
@login_required
def calculate_settlement_page():
    if request.method == 'POST':
        try:
            apartment_id = request.form['apartment_id']
            period_start = datetime.strptime(request.form['period_start'], '%Y-%m-%d').date()
            period_end = datetime.strptime(request.form['period_end'], '%Y-%m-%d').date()
            
            apartment = Apartment.query.get(apartment_id)
            tenant = Tenant.query.filter_by(apartment_id=apartment_id, move_out_date=None).first()
            
            if not tenant:
                flash('Kein aktiver Mieter für diese Wohnung gefunden', 'danger')
                return redirect(request.url)
            
            # Vereinfachte Berechnung
            total_rent = tenant.rent * 12  # Jahresmiete
            additional_costs = apartment.additional_costs * 12  # Jahresnebenkosten
            
            # Hier würden echte Verbrauchswerte berechnet werden
            heating_costs = 0
            water_costs = 0
            electricity_costs = 0
            
            total_amount = additional_costs + heating_costs + water_costs + electricity_costs
            
            settlement = Settlement(
                period_start=period_start,
                period_end=period_end,
                total_rent=total_rent,
                additional_costs=additional_costs,
                heating_costs=heating_costs,
                water_costs=water_costs,
                electricity_costs=electricity_costs,
                total_amount=total_amount,
                apartment_id=apartment_id,
                tenant_id=tenant.id
            )
            
            db.session.add(settlement)
            db.session.commit()
            
            flash('Abrechnung erfolgreich erstellt!', 'success')
            return redirect(url_for('main.settlement_detail_page', settlement_id=settlement.id))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Fehler beim Erstellen der Abrechnung: {str(e)}', 'danger')
    
    apartments = Apartment.query.all()
    return render_template('settlements/calculate.html', apartments=apartments)

@main_bp.route('/settlements/<settlement_id>')
@login_required
def settlement_detail_page(settlement_id):
    settlement = Settlement.query.get_or_404(settlement_id)
    return render_template('settlements/detail.html', settlement=settlement)

@main_bp.route('/settlements/<settlement_id>/pdf')
@login_required
def download_settlement_pdf_page(settlement_id):
    settlement = Settlement.query.get_or_404(settlement_id)
    # Hier würde die PDF-Generierung implementiert werden
    flash('PDF-Generierung wird in Kürze verfügbar sein', 'info')
    return redirect(url_for('main.settlement_detail_page', settlement_id=settlement_id))