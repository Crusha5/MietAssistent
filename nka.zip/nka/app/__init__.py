from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from flask_swagger_ui import get_swaggerui_blueprint
from datetime import datetime
import os

# Initialize extensions
db = SQLAlchemy()
jwt = JWTManager()

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-me')
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(os.path.abspath('data'), 'rental.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY', 'jwt-secret-key-change-me')

    app.config['UPLOAD_FOLDER'] = os.path.join(os.path.abspath('uploads'))
    app.config['PREFERRED_URL_SCHEME'] = os.environ.get('PREFERRED_URL_SCHEME', 'https')
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
    
    # Session Configuration
    app.config['SESSION_TYPE'] = 'filesystem'
    app.config['SESSION_PERMANENT'] = False
    app.config['SESSION_USE_SIGNER'] = True
    app.config['PERMANENT_SESSION_LIFETIME'] = 3600  # 1 Stunde
    app.config['SESSION_KEY_PREFIX'] = 'mietassistent_'
    
    # Initialize extensions with app
    db.init_app(app)
    jwt.init_app(app)
    CORS(app)
    
    # Swagger UI configuration
    SWAGGER_URL = '/api/docs'
    API_URL = '/static/swagger.json'
    
    swaggerui_blueprint = get_swaggerui_blueprint(
        SWAGGER_URL,
        API_URL,
        config={
            'app_name': "MietAssistent API"
        }
    )
    app.register_blueprint(swaggerui_blueprint, url_prefix=SWAGGER_URL)
    
    # Add now() function to Jinja2
    @app.context_processor
    def utility_processor():
        return dict(now=datetime.now)
    
    # Database initialization
    with app.app_context():
        try:
            from app.models import User, Building, Apartment, Tenant, Meter, MeterType, MeterReading, OperatingCost, CostCategory, Settlement, Document
            db.create_all()
            print("📦 Creating database tables...")
            print("✅ Database tables created")
            
            # Check if setup is needed
            users = User.query.first()
            if not users:
                print("⚠️  No users found - please run setup at /setup")
            else:
                print("✅ Setup already completed")
                
        except Exception as e:
            print(f"❌ Database initialization error: {e}")
    
    # Import and register blueprints - KORRIGIERTE REGISTRIERUNG OHNE KONFLIKTE
    
    # Setup Routes (Web only)
    try:
        from app.routes.setup import setup_bp
        app.register_blueprint(setup_bp, url_prefix='/setup')
        print("✅ Setup routes registered")
    except ImportError as e:
        print(f"❌ Failed to import setup routes: {e}")
    
    # Auth Routes (Web routes only)
    try:
        from app.routes.auth import auth_bp
        app.register_blueprint(auth_bp, url_prefix='/auth')
        print("✅ Auth routes registered")
    except ImportError as e:
        print(f"❌ Failed to import auth routes: {e}")
    
    # Main Routes (Web only)
    try:
        from app.routes.main import main_bp
        app.register_blueprint(main_bp)
        print("✅ Main routes registered")
    except ImportError as e:
        print(f"❌ Failed to import main routes: {e}")
    
    # Apartments Routes (Web routes only)
    try:
        from app.routes.apartments import apartments_bp
        app.register_blueprint(apartments_bp, url_prefix='/apartments')
        print("✅ Apartment routes registered")
    except ImportError as e:
        print(f"❌ Failed to import apartment routes: {e}")

    # Tenants Routes (Web routes only)
    try:
        from app.routes.tenants import tenants_bp
        app.register_blueprint(tenants_bp, url_prefix='/tenants')
        print("✅ Tenant routes registered")
    except ImportError as e:
        print(f"❌ Failed to import tenant routes: {e}")

    # Meter Readings Routes (Web routes only)
    try:
        from app.routes.meter_readings import meter_bp
        app.register_blueprint(meter_bp, url_prefix='/meter-readings')
        print("✅ Meter reading routes registered")
    except ImportError as e:
        print(f"❌ Failed to import meter reading routes: {e}")

    # Meter Management Routes (Web routes only) - ENTFERNT doppelte API-Registrierung
    try:
        from app.routes.meters import meters_bp
        app.register_blueprint(meters_bp, url_prefix='/meters')
        print("✅ Meter management routes registered")
    except ImportError as e:
        print(f"❌ Failed to import meter management routes: {e}")

    # Documents Routes (Web routes only)
    try:
        from app.routes.documents import documents_bp
        app.register_blueprint(documents_bp, url_prefix='/documents')
        print("✅ Document routes registered")
    except ImportError as e:
        print(f"❌ Failed to import document routes: {e}")

    # Settlements Routes (Web routes only)
    try:
        from app.routes.settlements import settlements_bp
        app.register_blueprint(settlements_bp, url_prefix='/settlements')
        print("✅ Settlement routes registered")
    except ImportError as e:
        print(f"❌ Failed to import settlement routes: {e}")

    # Buildings Routes (Web routes only)
    try:
        from app.routes.buildings import buildings_bp
        app.register_blueprint(buildings_bp, url_prefix='/buildings')
        print("✅ Buildings routes registered")
    except ImportError as e:
        print(f"❌ Failed to import buildings routes: {e}")

    # Meter Types Routes (neu)
    try:
        from app.routes.meter_types import meter_types_bp
        app.register_blueprint(meter_types_bp, url_prefix='/meter-types')
        print("✅ Meter types routes registered")
    except ImportError as e:
        print(f"❌ Failed to import meter types routes: {e}")

    # API Routes - NUR FÜR DIE, DIE SEPARATE API-ENDPOINTS BENÖTIGEN
    # ACHTUNG: Keine doppelte Registrierung von Blueprints, die bereits oben registriert sind
    
    # Auth API Routes (separate registration)
    try:
        from app.routes.auth import auth_api_bp
        app.register_blueprint(auth_api_bp, url_prefix='/api/auth')
        print("✅ Auth API routes registered")
    except ImportError as e:
        print(f"⚠️  Auth API routes not available: {e}")
        # Fallback: Verwende vorhandene auth_bp für API, wenn separater API-BP nicht existiert
        try:
            from app.routes.auth import auth_bp
            app.register_blueprint(auth_bp, url_prefix='/api/auth')
            print("✅ Auth API routes (fallback) registered")
        except:
            print("❌ No auth API routes available")

    # Buildings API Routes (separate registration)
    try:
        from app.routes.buildings import buildings_api_bp
        app.register_blueprint(buildings_api_bp, url_prefix='/api/buildings')
        print("✅ Buildings API routes registered")
    except ImportError as e:
        print(f"⚠️  Buildings API routes not available: {e}")

    # Apartments API Routes (separate registration)
    try:
        from app.routes.apartments import apartments_api_bp
        app.register_blueprint(apartments_api_bp, url_prefix='/api/apartments')
        print("✅ Apartments API routes registered")
    except ImportError as e:
        print(f"⚠️  Apartments API routes not available: {e}")

    # Meter Readings API Routes (separate registration)
    try:
        from app.routes.meter_readings import meter_readings_api_bp
        app.register_blueprint(meter_readings_api_bp, url_prefix='/api/meter-readings')
        print("✅ Meter readings API routes registered")
    except ImportError as e:
        print(f"⚠️  Meter readings API routes not available: {e}")

    # Documents API Routes (separate registration)
    try:
        from app.routes.documents import documents_api_bp
        app.register_blueprint(documents_api_bp, url_prefix='/api/documents')
        print("✅ Documents API routes registered")
    except ImportError as e:
        print(f"⚠️  Documents API routes not available: {e}")

    # Settlements API Routes (separate registration)
    try:
        from app.routes.settlements import settlements_api_bp
        app.register_blueprint(settlements_api_bp, url_prefix='/api/settlements')
        print("✅ Settlements API routes registered")
    except ImportError as e:
        print(f"⚠️  Settlements API routes not available: {e}")

    # Costs Routes (optional - if they exist)
    try:
        from app.routes.costs import costs_bp
        app.register_blueprint(costs_bp, url_prefix='/costs')
        print("✅ Costs routes registered")
    except ImportError as e:
        print(f"⚠️  Costs routes not available: {e}")
    
    # Reports Routes (optional - if they exist)
    try:
        from app.routes.reports import reports_bp
        app.register_blueprint(reports_bp, url_prefix='/reports')
        print("✅ Reports routes registered")
    except ImportError as e:
        print(f"⚠️  Reports routes not available: {e}")
    
    # Settings Routes (optional - if they exist)
    try:
        from app.routes.settings import settings_bp
        app.register_blueprint(settings_bp, url_prefix='/settings')
        print("✅ Settings routes registered")
    except ImportError as e:
        print(f"⚠️  Settings routes not available: {e}")
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({'error': 'Resource not found'}), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500
    
    @app.errorhandler(413)
    def too_large(error):
        return jsonify({'error': 'File too large'}), 413

    # Health check endpoint
    @app.route('/health')
    def health_check():
        try:
            # Test database connection
            db.session.execute('SELECT 1')
            db_status = 'connected'
        except Exception as e:
            db_status = f'disconnected: {str(e)}'
        
        return jsonify({
            'status': 'healthy',
            'database': db_status,
            'timestamp': datetime.now().isoformat()
        })
    
    # Debug: Zeige alle registrierten Routes beim Start
    with app.app_context():
        print("📋 Registered routes:")
        for rule in app.url_map.iter_rules():
            print(f"  {rule.endpoint}: {rule.rule} [{', '.join(rule.methods)}]")
    
    # Root endpoint - redirect to dashboard if logged in, otherwise to login
    @app.route('/')
    def index():
        from flask import redirect, session
        from app.models import User
        
        # If no users exist, redirect to setup
        if not User.query.first():
            return redirect('/setup')
        
        # If user is logged in, redirect to dashboard
        if 'user_id' in session:
            return redirect('/dashboard')
        
        # Otherwise redirect to login
        return redirect('/auth/login')
    
    print("🚀 Starting Flask server on port 5000...")
    print("📊 Access the application at: http://localhost:5000")

    # Debug endpoint to check database status
    @app.route('/debug/db-status')
    def debug_db_status():
        try:
            from app.models import Apartment, Building
            apartment_count = Apartment.query.count()
            building_count = Building.query.count()
            
            return jsonify({
                'database': 'connected',
                'apartments_count': apartment_count,
                'buildings_count': building_count,
                'tables_accessible': True
            })
        except Exception as e:
            return jsonify({
                'database': 'error',
                'error': str(e)
            }), 500
    
    return app